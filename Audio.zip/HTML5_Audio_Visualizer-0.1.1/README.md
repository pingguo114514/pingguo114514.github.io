HTML5 Audio Visualizer
======================

An audio spectrum visualizer built with HTML5 Audio API

Demo
---
[See it in action](http://wayouliu.duapp.com/mess/audio_visualizer.html).

Screen Capture
---
![alt tag](https://raw.github.com/Wayou/HTML5_Audio_Visualizer/master/sources/screencapture.png)
